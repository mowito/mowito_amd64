
"use strict";

let LoadTaskFromFile = require('./LoadTaskFromFile.js')
let SetRobotFootprint = require('./SetRobotFootprint.js')
let SetTask = require('./SetTask.js')
let GetPose = require('./GetPose.js')
let GetCircumscribedRadius = require('./GetCircumscribedRadius.js')
let LoadRouteFromFile = require('./LoadRouteFromFile.js')
let SetCost = require('./SetCost.js')
let GetPlan = require('./GetPlan.js')
let SetPlan = require('./SetPlan.js')
let SetRoute = require('./SetRoute.js')
let GetRoute = require('./GetRoute.js')
let SetDuty = require('./SetDuty.js')
let SetNodeState = require('./SetNodeState.js')
let ComputeCircumscribedCost = require('./ComputeCircumscribedCost.js')
let GetSbplPlan = require('./GetSbplPlan.js')
let GetRouteStatus = require('./GetRouteStatus.js')
let GetDuty = require('./GetDuty.js')
let GetDouble = require('./GetDouble.js')
let GetTaskStatus = require('./GetTaskStatus.js')
let SetMode = require('./SetMode.js')
let LoadDutyFromFile = require('./LoadDutyFromFile.js')
let GetTask = require('./GetTask.js')
let GetString = require('./GetString.js')
let SetString = require('./SetString.js')

module.exports = {
  LoadTaskFromFile: LoadTaskFromFile,
  SetRobotFootprint: SetRobotFootprint,
  SetTask: SetTask,
  GetPose: GetPose,
  GetCircumscribedRadius: GetCircumscribedRadius,
  LoadRouteFromFile: LoadRouteFromFile,
  SetCost: SetCost,
  GetPlan: GetPlan,
  SetPlan: SetPlan,
  SetRoute: SetRoute,
  GetRoute: GetRoute,
  SetDuty: SetDuty,
  SetNodeState: SetNodeState,
  ComputeCircumscribedCost: ComputeCircumscribedCost,
  GetSbplPlan: GetSbplPlan,
  GetRouteStatus: GetRouteStatus,
  GetDuty: GetDuty,
  GetDouble: GetDouble,
  GetTaskStatus: GetTaskStatus,
  SetMode: SetMode,
  LoadDutyFromFile: LoadDutyFromFile,
  GetTask: GetTask,
  GetString: GetString,
  SetString: SetString,
};
