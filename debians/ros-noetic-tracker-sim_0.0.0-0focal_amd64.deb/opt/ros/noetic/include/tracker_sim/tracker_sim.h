/**
* @file tracker_sim.h
* @author Divyanshu Sahu
* @brief This node takes the commands given by the keyboard_teleop node and publishes the tracker position and goal for the robot to follow
*/
#pragma once
//required header files
#include <geometry_msgs/Twist.h>
#include <geometry_msgs/Pose.h>
#include <stdio.h>
#include <unistd.h>
#include <termios.h>
#include <ros/ros.h>
#include <tf/transform_broadcaster.h>
#include <map>
#include <deque>
#include <visualization_msgs/Marker.h>
#include <tf/transform_datatypes.h>

namespace mw_tracker{

	class Tracker
	{
		public:
			Tracker(double loop_rate_value);

			static geometry_msgs::Quaternion createQuaternionFromRPY(double roll, double pitch, double yaw);

			void publishtrackergoal(double x_pos, double y_pos, geometry_msgs::Quaternion tracker_orientation);

			void teleopGoalCb(const geometry_msgs::Twist::Ptr& msg);

			void trackerExecute();

		private:

			ros::NodeHandle nh_;
			ros::NodeHandle private_nh_; 
			std::string map_frame_, tracker_frame_, tracker_pose_topic_, teleop_sub_topic_;
			ros::Subscriber teleop_sub_;	//keyboard_teleop node subscriber
			ros::Publisher goal_pub_; 	//goal publisher 
			ros::Publisher marker_pub_; 	//publishing marker for better visulaisation
			float delta_t_;			//loop rate parameter
			float tracker_vel_x_, tracker_vel_th_; //velocity of the tracker as recieved from the keyboard_teleop node
			float tracker_pos_x_, tracker_pos_th_; //position of the tracker with respect to the tracker itself
			float map_pos_x_, map_pos_th_, map_pos_y_; //position of the tracker with respect to the map frame
			float tracker_init_pose_x_, tracker_init_pose_y_; //initial x and y position of the tracker 
			bool is_tracker_published_;		//flag to check when the keyboard commands are published
			bool tracker_init_goal_;			//flag to check if the goal is the first goal
			geometry_msgs::PoseStamped tracker_pose_;	//tracker pose to be published
  			tf::TransformBroadcaster br_;		
  			tf::Transform transform_;
	};
}