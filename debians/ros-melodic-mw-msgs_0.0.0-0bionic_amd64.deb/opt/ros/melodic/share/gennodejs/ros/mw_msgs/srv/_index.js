
"use strict";

let SetString = require('./SetString.js')
let LoadTaskFromFile = require('./LoadTaskFromFile.js')
let SetTask = require('./SetTask.js')
let GetTaskStatus = require('./GetTaskStatus.js')
let SetMode = require('./SetMode.js')
let ComputeCircumscribedCost = require('./ComputeCircumscribedCost.js')
let SetRobotFootprint = require('./SetRobotFootprint.js')
let GetRoute = require('./GetRoute.js')
let GetPose = require('./GetPose.js')
let SetRoute = require('./SetRoute.js')
let GetString = require('./GetString.js')
let GetDouble = require('./GetDouble.js')
let GetRouteStatus = require('./GetRouteStatus.js')
let GetCircumscribedRadius = require('./GetCircumscribedRadius.js')
let SetCost = require('./SetCost.js')
let SetNodeState = require('./SetNodeState.js')
let LoadRouteFromFile = require('./LoadRouteFromFile.js')
let GetTask = require('./GetTask.js')
let SetDuty = require('./SetDuty.js')
let SetPlan = require('./SetPlan.js')
let GetPlan = require('./GetPlan.js')
let LoadDutyFromFile = require('./LoadDutyFromFile.js')
let GetSbplPlan = require('./GetSbplPlan.js')
let GetDuty = require('./GetDuty.js')

module.exports = {
  SetString: SetString,
  LoadTaskFromFile: LoadTaskFromFile,
  SetTask: SetTask,
  GetTaskStatus: GetTaskStatus,
  SetMode: SetMode,
  ComputeCircumscribedCost: ComputeCircumscribedCost,
  SetRobotFootprint: SetRobotFootprint,
  GetRoute: GetRoute,
  GetPose: GetPose,
  SetRoute: SetRoute,
  GetString: GetString,
  GetDouble: GetDouble,
  GetRouteStatus: GetRouteStatus,
  GetCircumscribedRadius: GetCircumscribedRadius,
  SetCost: SetCost,
  SetNodeState: SetNodeState,
  LoadRouteFromFile: LoadRouteFromFile,
  GetTask: GetTask,
  SetDuty: SetDuty,
  SetPlan: SetPlan,
  GetPlan: GetPlan,
  LoadDutyFromFile: LoadDutyFromFile,
  GetSbplPlan: GetSbplPlan,
  GetDuty: GetDuty,
};
