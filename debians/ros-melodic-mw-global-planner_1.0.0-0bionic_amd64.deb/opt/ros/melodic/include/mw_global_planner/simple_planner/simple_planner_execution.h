/**
 * @file simple_planner_execution.h
 * @brief simple planner execution class
 * @author Sourav Agrawal<sourav.agrawal@mowito.in>
 */

#ifndef MW_GLOBAL_PLANNER_SIMPLE_PLANNER_EXECUTION_H
#define MW_GLOBAL_PLANNER_SIMPLE_PLANNER_EXECUTION_H

#include <mw_global_planner/base_planner_execution.h>

namespace mw_global_planner {

class SimplePlannerExecution : public mw_global_planner::AbstractPlannerExecution {

 public:

  SimplePlannerExecution();

  ~SimplePlannerExecution();
};

}

#endif //MW_GLOBAL_PLANNER_SIMPLE_PLANNER_EXECUTION_H
