// Auto-generated. Do not edit!

// (in-package mw_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class mission_status {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.nav_mode = null;
      this.autonomy_state = null;
      this.controller_type = null;
      this.global_planner_type = null;
      this.current_pose = null;
      this.current_goal = null;
    }
    else {
      if (initObj.hasOwnProperty('nav_mode')) {
        this.nav_mode = initObj.nav_mode
      }
      else {
        this.nav_mode = '';
      }
      if (initObj.hasOwnProperty('autonomy_state')) {
        this.autonomy_state = initObj.autonomy_state
      }
      else {
        this.autonomy_state = '';
      }
      if (initObj.hasOwnProperty('controller_type')) {
        this.controller_type = initObj.controller_type
      }
      else {
        this.controller_type = '';
      }
      if (initObj.hasOwnProperty('global_planner_type')) {
        this.global_planner_type = initObj.global_planner_type
      }
      else {
        this.global_planner_type = '';
      }
      if (initObj.hasOwnProperty('current_pose')) {
        this.current_pose = initObj.current_pose
      }
      else {
        this.current_pose = new geometry_msgs.msg.PoseStamped();
      }
      if (initObj.hasOwnProperty('current_goal')) {
        this.current_goal = initObj.current_goal
      }
      else {
        this.current_goal = new geometry_msgs.msg.PoseStamped();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type mission_status
    // Serialize message field [nav_mode]
    bufferOffset = _serializer.string(obj.nav_mode, buffer, bufferOffset);
    // Serialize message field [autonomy_state]
    bufferOffset = _serializer.string(obj.autonomy_state, buffer, bufferOffset);
    // Serialize message field [controller_type]
    bufferOffset = _serializer.string(obj.controller_type, buffer, bufferOffset);
    // Serialize message field [global_planner_type]
    bufferOffset = _serializer.string(obj.global_planner_type, buffer, bufferOffset);
    // Serialize message field [current_pose]
    bufferOffset = geometry_msgs.msg.PoseStamped.serialize(obj.current_pose, buffer, bufferOffset);
    // Serialize message field [current_goal]
    bufferOffset = geometry_msgs.msg.PoseStamped.serialize(obj.current_goal, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type mission_status
    let len;
    let data = new mission_status(null);
    // Deserialize message field [nav_mode]
    data.nav_mode = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [autonomy_state]
    data.autonomy_state = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [controller_type]
    data.controller_type = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [global_planner_type]
    data.global_planner_type = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [current_pose]
    data.current_pose = geometry_msgs.msg.PoseStamped.deserialize(buffer, bufferOffset);
    // Deserialize message field [current_goal]
    data.current_goal = geometry_msgs.msg.PoseStamped.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.nav_mode);
    length += _getByteLength(object.autonomy_state);
    length += _getByteLength(object.controller_type);
    length += _getByteLength(object.global_planner_type);
    length += geometry_msgs.msg.PoseStamped.getMessageSize(object.current_pose);
    length += geometry_msgs.msg.PoseStamped.getMessageSize(object.current_goal);
    return length + 16;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mw_msgs/mission_status';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '51f1f95c076360d1d37acc68754b3e71';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # status indicating the navigation mode of executive (AUTONOMY/MANUAL/SAFETELEOP)
    string nav_mode
    
    # status indicating machine state (PLANNING/CONTROLLING/RECOVERING/WAITING/NA) (NA state is when mission nav_mode is working in Manual or Safe telop mode)
    string autonomy_state
    
    # status indicating name of the controller type being used
    string controller_type
    
    # status indicating name of the global planner type being used
    string global_planner_type
    
    # status indicating current position and orientation of the robot
    geometry_msgs/PoseStamped current_pose
    
    # status indicating the current goal being pursued by the robot 
    geometry_msgs/PoseStamped current_goal
    ================================================================================
    MSG: geometry_msgs/PoseStamped
    # A Pose with reference coordinate frame and timestamp
    Header header
    Pose pose
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new mission_status(null);
    if (msg.nav_mode !== undefined) {
      resolved.nav_mode = msg.nav_mode;
    }
    else {
      resolved.nav_mode = ''
    }

    if (msg.autonomy_state !== undefined) {
      resolved.autonomy_state = msg.autonomy_state;
    }
    else {
      resolved.autonomy_state = ''
    }

    if (msg.controller_type !== undefined) {
      resolved.controller_type = msg.controller_type;
    }
    else {
      resolved.controller_type = ''
    }

    if (msg.global_planner_type !== undefined) {
      resolved.global_planner_type = msg.global_planner_type;
    }
    else {
      resolved.global_planner_type = ''
    }

    if (msg.current_pose !== undefined) {
      resolved.current_pose = geometry_msgs.msg.PoseStamped.Resolve(msg.current_pose)
    }
    else {
      resolved.current_pose = new geometry_msgs.msg.PoseStamped()
    }

    if (msg.current_goal !== undefined) {
      resolved.current_goal = geometry_msgs.msg.PoseStamped.Resolve(msg.current_goal)
    }
    else {
      resolved.current_goal = new geometry_msgs.msg.PoseStamped()
    }

    return resolved;
    }
};

module.exports = mission_status;
