// Auto-generated. Do not edit!

// (in-package mw_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class ChangeMprimsRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.FolderName = null;
    }
    else {
      if (initObj.hasOwnProperty('FolderName')) {
        this.FolderName = initObj.FolderName
      }
      else {
        this.FolderName = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ChangeMprimsRequest
    // Serialize message field [FolderName]
    bufferOffset = _serializer.string(obj.FolderName, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ChangeMprimsRequest
    let len;
    let data = new ChangeMprimsRequest(null);
    // Deserialize message field [FolderName]
    data.FolderName = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.FolderName);
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'mw_msgs/ChangeMprimsRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '840574e1913b90e04939534507dd51ab';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string FolderName
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ChangeMprimsRequest(null);
    if (msg.FolderName !== undefined) {
      resolved.FolderName = msg.FolderName;
    }
    else {
      resolved.FolderName = ''
    }

    return resolved;
    }
};

class ChangeMprimsResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.pathFolder = null;
    }
    else {
      if (initObj.hasOwnProperty('pathFolder')) {
        this.pathFolder = initObj.pathFolder
      }
      else {
        this.pathFolder = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ChangeMprimsResponse
    // Serialize message field [pathFolder]
    bufferOffset = _serializer.string(obj.pathFolder, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ChangeMprimsResponse
    let len;
    let data = new ChangeMprimsResponse(null);
    // Deserialize message field [pathFolder]
    data.pathFolder = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.pathFolder);
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'mw_msgs/ChangeMprimsResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'becfe7b4a101a15e2fab90908005f0e3';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string pathFolder
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ChangeMprimsResponse(null);
    if (msg.pathFolder !== undefined) {
      resolved.pathFolder = msg.pathFolder;
    }
    else {
      resolved.pathFolder = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: ChangeMprimsRequest,
  Response: ChangeMprimsResponse,
  md5sum() { return '835f45e3f104eff6859613fa681bf5a9'; },
  datatype() { return 'mw_msgs/ChangeMprims'; }
};
