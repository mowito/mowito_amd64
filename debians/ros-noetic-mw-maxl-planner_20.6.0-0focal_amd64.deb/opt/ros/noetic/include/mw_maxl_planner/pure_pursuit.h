/**
 *
 * @file pure_pursuit.h
 * @brief The Pure Pursuit Path Follower class.
 * @author Puru Rastogi <puru@mowito.in>
 *
 */

#ifndef PURE_PURSUIT_H
#define PURE_PURSUIT_H

// C++ classes
#include <math.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>

// Mowito Nav Stack base class
// #include <controller_executive/base_controller.h>


// PCL header
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/kdtree/kdtree_flann.h>

#include <pcl_ros/point_cloud.h>
#include <pcl_ros/transforms.h>

// ROS Message
#include <std_msgs/Bool.h>
#include <std_msgs/Float32.h>
#include <nav_msgs/Path.h>
#include <nav_msgs/Odometry.h>

#include <geometry_msgs/Pose2D.h>
#include <geometry_msgs/PointStamped.h>
#include <geometry_msgs/PolygonStamped.h>
#include <sensor_msgs/Imu.h>
#include <sensor_msgs/PointCloud2.h>
#include <sensor_msgs/Joy.h>
#include <sensor_msgs/LaserScan.h>

#include <geometry_msgs/Twist.h>

// Others
#include <laser_geometry/laser_geometry.h>
#include <message_filters/subscriber.h>
#include <message_filters/synchronizer.h>
#include <message_filters/sync_policies/approximate_time.h>

#include <nav_msgs/Path.h>

// dynamic reconfigure
#include <dynamic_reconfigure/server.h>
#include <mw_maxl_planner/MaxLPlannerConfig.h>

#include <maxl_logger.h>

// #define M_PI 3.1415926

namespace mw_maxl_planner
{

  /**
    * @class MaxlPlanner
    * @brief Implements both controller::AbstractController
    */
  class PurePursuit
  {
    public:
      /**
        * @brief Default constructor of the teb plugin
        */
      PurePursuit(double min_lookahead,
                  double max_lookahead,
                  int closest_point_index_search,
                  double max_y_deviation,
                  double min_radius,
                  double max_radius,
                  double max_omega_radius,
                  double max_path_dev,
                  double lookahead_point_distance,
                  //for oscillation
                  double lookahead_factor_val,
                  double lookahead_jump_threshold);

      /**
        * @brief  Destructor of the plugin
        */
      // ~PurePursuit(); //this has not been defined in pure_pursuit.cpp which means it's not user defined.

    public:
      geometry_msgs::Pose2D getLookAheadGoal();
      void setOdometry(const geometry_msgs::PoseStamped pose);
      void setVelodynScan(const pcl::PointCloud<pcl::PointXYZI>::Ptr& CloudCrop);
      void setLaserScan(const pcl::PointCloud<pcl::PointXYZI>::Ptr& CloudCrop);
      void setGlobalPath(const std::vector<geometry_msgs::Pose2D>& path);
      void clearPlan();

    protected:
      double calculateXYDeviation(const geometry_msgs::Pose2D &pose1, const geometry_msgs::Pose2D &pose2);
      geometry_msgs::Pose2D getIntersection(bool is_vert_1, double m_1, double c_1,
                                            bool is_vert_2, double m_2, double c_2);
      double getRadiusOfCurvature(const geometry_msgs::Pose2D pose1, const geometry_msgs::Pose2D pose2);
      double getRadiusOfCurvatureOfGoalPoints();
      double improveLookahead(double lookahead, double path_deviation);
      int findClosestPose();
      double getLookahead(const double &_curv);
      int getTargetPoseIndex(const double &lookahead);

    private:
      int closest_pose_idx_;
      double min_lookahead_;
      double max_lookahead_;
      int closest_point_index_search_;
      double max_y_deviation_;
      double min_radius_;
      double max_radius_;
      double max_omega_radius_;
      double max_path_dev_;
      double lookahead_point_distance_;
      bool handle_oscillation_flag_; //if the lookahead goal jumps, this flag will be true until the lookahead goal reaches the intended lookahead goal
      double DEFAULT_LOOKAHEAD_FACTOR_VAL_; //default value of lookahead_update_factor_
      double lookahead_factor_val_; //the factor with which the jump mangnitude gets multiplied. Controls the senstivity of jumps. Lower the value, the lower the change in lookahead goal.
      double old_lookahead_, new_lookahead_; //variables to store old and new lookahead values
      double DIFF_THRESHHOLD_; //if the jump in lookahead values is greater than this value, it would be considered as an oscillation.  
      double OSC_THRESHHOLD_; //the maximum difference in lookahead values after which the jump is not treated as an oscillation

      std::vector<geometry_msgs::Pose2D> global_path_;
      pcl::PointCloud<pcl::PointXYZI>::Ptr laserCloudCrop = pcl::PointCloud<pcl::PointXYZI>::Ptr(new pcl::PointCloud<pcl::PointXYZI>());
      geometry_msgs::Pose2D current_pose_;
  };

} // end namespace maxl_planner

#endif // MAXL_PLANNER_H_
