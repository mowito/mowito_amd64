/**
* @file recovery_control.h
* @author Divyanshu Sahu
* @brief Header file which creates a custom control node for recovery of the robot if the robot isSruckCondition returns FAILURE (We have used an inverter in the tree). 
* This node works in a similar manner to the nav2 recovery control node (link: https://github.com/ros-planning/navigation2/tree/main/nav2_bt_navigator)
*/

//required header files
#ifndef RECOVERY_CONTROL
#define RECOVERY_CONTROL

#include <mw_msgs/GetPathAction.h> 
#include <mw_msgs/ExePathAction.h>
#include <mw_msgs/SetString.h>
#include <actionlib/client/simple_action_client.h>
#include "behaviortree_cpp_v3/bt_factory.h"
#include "behaviortree_cpp_v3/behavior_tree.h"
#include <ros/ros.h>
#include "geometry_msgs/Pose.h"
#include "geometry_msgs/PoseStamped.h"
#include <geometry_msgs/Twist.h>
#include <vector>
#include <executive/mission_executive.h>
#include <fstream>
#include <sstream>
#include <string>
#include <iostream>
#include <string>
#include "behaviortree_cpp_v3/control_node.h" 


using namespace BT;
using namespace std;


namespace bt_mowito{

	class RecoveryControl : public BT::ControlNode
	{
	public:

	  	RecoveryControl(const std::string & name, const BT::NodeConfiguration & conf);

		~RecoveryControl() override = default ;

		static BT::PortsList providedPorts()
		{
		    return 
		    {
		      	BT::InputPort<int>("number_of_retries", 1, "Number of retries")
		    };
		}

		BT::NodeStatus tick() override;
		void halt() override;

	private:
		unsigned int current_child_idx_;
		unsigned int number_of_retries_;
		unsigned int retry_count_;
	}; //class ends here

}  // namespace bt_mowito


#endif