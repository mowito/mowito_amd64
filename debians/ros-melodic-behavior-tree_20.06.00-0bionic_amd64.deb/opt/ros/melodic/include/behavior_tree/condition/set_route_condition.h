/**
* @file set_route_condition_action.h
* @author Divyanshu Sahu
* @brief Header file for setting a route via yaml file. This file has similar elements to the set_plan_condition.h and the set_waypoint_condition.h files
*/

//required header files
#ifndef SET_ROUTE_CONDITION
#define SET_ROUTE_CONDITION

#include "behaviortree_cpp_v3/behavior_tree.h"
#include "behaviortree_cpp_v3/bt_factory.h"
#include <mw_msgs/GetPathAction.h> 
#include <mw_msgs/ExePathAction.h>
#include <nav_msgs/Odometry.h>
#include <actionlib/client/simple_action_client.h>
#include "behaviortree_cpp_v3/bt_factory.h"
#include "behaviortree_cpp_v3/behavior_tree.h"
#include <ros/ros.h>
#include "geometry_msgs/Pose.h"
#include "geometry_msgs/PoseStamped.h"
#include <vector>
#include <executive/mission_executive.h>
#include <fstream>
#include <sstream>
#include <string>
#include <iostream>

using namespace BT;
using namespace std;

namespace bt_mowito
{

	class setroutecondition : public ConditionNode
		{
  		public:
   			setroutecondition(const std::string& condition_name, const NodeConfiguration& conf);

   			static BT::PortsList providedPorts() {return {OutputPort<geometry_msgs::PoseStamped>("the_waypoints"), InputPort<bool>("in_flag"), OutputPort<int>("start_bt_flag"),  OutputPort<bool>("out_flag")};}
	    		/*
	            * brief:The method for initialising the required input and output ports for the BLACKBOARD
	            * Input Port: the "in_flag" is used to know if the followpath_action is done or not 
	            * Output port: the "the_waypoints" is used to set the required goal on the BLACKBOARD. The "start_bt_flag" is to know if the robot has been in hybernation or not. 
	            * the "out_flag" is an initialsing port for the "in_flag". 
	            */

                  bool setCurrentRoute(mw_msgs::SetRoute::Request &req, mw_msgs::SetRoute::Response &resp);

   		BT::NodeStatus tick() override;

                  void callback(const nav_msgs::Odometry::ConstPtr &msg);

                  void publishQueue(); 

                  bool goal_reached();

   		private:

   	         	ros::NodeHandle nh5;
                  ros::ServiceServer set_route_;  
                  ros::Publisher goal_pub; 
                  bool service_call;
                  bool was_stuck;
                  int start_bt_flag;
                  int tick_count;
                  ros::Subscriber odom_sub_;
                  std::deque<geometry_msgs::PoseStamped> planner_queue;
                  std::deque<nav_msgs::Odometry> odom_history;
                  std::deque<nav_msgs::Odometry>::size_type odom_history_size_;
            };

}
#endif   