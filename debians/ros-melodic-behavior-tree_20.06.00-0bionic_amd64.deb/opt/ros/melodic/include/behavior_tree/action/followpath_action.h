/**
* @file followpath_action.h
* @author Divyanshu Sahu
* @brief Header file for invoking the controller action server with the path and controlling the robot until the path has been traversed
*/
#ifndef CONTROLLER_TO_POSE
#define CONTROLLER_TO_POSE

//required header files
#include <mw_msgs/GetPathAction.h> 
#include <mw_msgs/ExePathAction.h>
#include <mw_msgs/SetString.h>
#include <actionlib/client/simple_action_client.h>
#include "behaviortree_cpp_v3/bt_factory.h"
#include "behaviortree_cpp_v3/behavior_tree.h"
#include <ros/ros.h>
#include "geometry_msgs/Pose.h"
#include "geometry_msgs/PoseStamped.h"
#include <geometry_msgs/Twist.h>
#include <vector>
#include <executive/mission_executive.h>
#include <fstream>
#include <sstream>
#include <string>
#include <iostream>

using namespace BT;
using namespace std;





namespace bt_mowito{

            //Controller Coroutine class. 
	class ControllerAction : public CoroActionNode
	{
  		public:
   		ControllerAction(const std::string& name, const NodeConfiguration& config);

    		static PortsList providedPorts()
    		{
        		return{ InputPort<nav_msgs::Path>("the_path"), OutputPort<bool>("the_flag")};
    		}
                        /*
                        * brief:The method for initialising the required input and output ports for the BLACKBOARD
                        * Input Port: the path to be given to the controller action server 
                        * Output port: the done flag indicating the successful completion of the controller action server
                        */

    		void done(const actionlib::SimpleClientGoalState& state,
                               const mw_msgs::ExePathResultConstPtr& res);

    		void activeController();
    		void feedbackController(const mw_msgs::ExePathFeedbackConstPtr &feedback);

                        bool abortController(std_srvs::Empty::Request &req, std_srvs::Empty::Response &resp);
                        //brief: Service server callback to abort the current path being pursued by the controller action server 

                        bool changeController(mw_msgs::SetString::Request &req, mw_msgs::SetString::Response &resp);
                        //brief: Service server callback to change the controller according to requirement

    		BT::NodeStatus tick() override;

                        void halt() override;

    	private:
             ros::NodeHandle nh2;  //nodehandle
             geometry_msgs::Twist cmd_vel_zero_, cmd_vel_; //publishing zero velocity when required and publishing the velocity given by the controller action server
             mw_msgs::ExePathGoal cont_goal;  // goal to be sent to the controller action server
             actionlib::SimpleActionClient<mw_msgs::ExePathAction> controllerclient; //action client to the action server
             ros::Publisher cmd_vel_pub_ ;  //publisher object 
             ros::ServiceServer abort_controller;  //Server allows halting the current path pursued 
             bool is_succeed; //Flag for the coroaction done condition
             ros::ServiceServer change_controller_;  // Server that allows dynamic controller changes
             std::string controller_name_;    //name of the controller
    	};

}
#endif   