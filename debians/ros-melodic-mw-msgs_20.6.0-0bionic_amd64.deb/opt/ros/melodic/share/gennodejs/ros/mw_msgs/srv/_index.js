
"use strict";

let GetTask = require('./GetTask.js')
let GetDouble = require('./GetDouble.js')
let SetDuty = require('./SetDuty.js')
let SetRoute = require('./SetRoute.js')
let LoadRouteFromFile = require('./LoadRouteFromFile.js')
let SetCost = require('./SetCost.js')
let LoadTaskFromFile = require('./LoadTaskFromFile.js')
let SetTask = require('./SetTask.js')
let ComputeCircumscribedCost = require('./ComputeCircumscribedCost.js')
let SetMode = require('./SetMode.js')
let SetRobotFootprint = require('./SetRobotFootprint.js')
let GetString = require('./GetString.js')
let SetPlan = require('./SetPlan.js')
let GetDuty = require('./GetDuty.js')
let GetPlan = require('./GetPlan.js')
let GetCircumscribedRadius = require('./GetCircumscribedRadius.js')
let GetRouteStatus = require('./GetRouteStatus.js')
let GetPose = require('./GetPose.js')
let SetString = require('./SetString.js')
let GetTaskStatus = require('./GetTaskStatus.js')
let GetRoute = require('./GetRoute.js')
let SetNodeState = require('./SetNodeState.js')
let GetSbplPlan = require('./GetSbplPlan.js')
let LoadDutyFromFile = require('./LoadDutyFromFile.js')

module.exports = {
  GetTask: GetTask,
  GetDouble: GetDouble,
  SetDuty: SetDuty,
  SetRoute: SetRoute,
  LoadRouteFromFile: LoadRouteFromFile,
  SetCost: SetCost,
  LoadTaskFromFile: LoadTaskFromFile,
  SetTask: SetTask,
  ComputeCircumscribedCost: ComputeCircumscribedCost,
  SetMode: SetMode,
  SetRobotFootprint: SetRobotFootprint,
  GetString: GetString,
  SetPlan: SetPlan,
  GetDuty: GetDuty,
  GetPlan: GetPlan,
  GetCircumscribedRadius: GetCircumscribedRadius,
  GetRouteStatus: GetRouteStatus,
  GetPose: GetPose,
  SetString: SetString,
  GetTaskStatus: GetTaskStatus,
  GetRoute: GetRoute,
  SetNodeState: SetNodeState,
  GetSbplPlan: GetSbplPlan,
  LoadDutyFromFile: LoadDutyFromFile,
};
