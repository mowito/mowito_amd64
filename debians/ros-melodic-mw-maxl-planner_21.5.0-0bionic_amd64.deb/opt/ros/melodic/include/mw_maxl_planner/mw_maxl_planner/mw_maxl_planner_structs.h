#ifndef MAXL_PLANNER_STRUCTS_
#define MAXL_PLANNER_STRUCTS_

#include <vector>
#include <iostream>
#include <string.h>
#include <math.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
using namespace std;
namespace mw_maxl_planner
{
	struct Point
	{
		double x;
		double y;
		double z;
	};

	struct Pose2d
	{
		double x;
		double y;
		double z;
		double theta;  //range: [3.14, -3.14) 
	};

	struct Header
	{
		double time;
		std::string frame_id;
	};

	struct PointStamped
	{
		Point point;
		Header header;
	};

	struct TwistStamped
	{
		Point linear;
		Point angular;
		Header header;
	};

	struct Pose2dStamped
	{
		Pose2d pose;
		Header header;
	};

	struct Path
	{
		std::vector<Pose2d> poses;
		Header header; 
		
	};
	struct PurePursuitParam
	{
		double min_lookahead;
		double max_lookahead;
		int closest_point_index_search;
	    double max_y_deviation;
	    double min_radius;
	    double max_radius;
	    double max_omega_radius;
	    double max_path_dev;
	    double lookahead_point_distance;
	    double lookahead_factor_val;
	    double lookahead_jump_threshold;
		PurePursuitParam()
		{
			min_lookahead = 0.2;
			max_lookahead = 2.0;
			closest_point_index_search = 10.0;
	    	max_y_deviation = 0.5;
			min_radius = 0.1;
			max_radius = 1.0;
			max_omega_radius = 1.0;
			max_path_dev = 1.0;
			lookahead_point_distance = 0.1;
			lookahead_factor_val = 0.088;
			lookahead_jump_threshold = 0.05;		
		}

		void set(mw_maxl_planner::PurePursuitParam PurePursuitParam)
		{
		    min_lookahead = PurePursuitParam.min_lookahead;
		    max_lookahead = PurePursuitParam.max_lookahead;
		    closest_point_index_search = PurePursuitParam.closest_point_index_search;
		    max_y_deviation = PurePursuitParam.max_y_deviation;
		    min_radius = PurePursuitParam.min_radius;
		    max_radius = PurePursuitParam.max_radius;
		    max_omega_radius = PurePursuitParam.max_omega_radius;
		    max_path_dev = PurePursuitParam.max_path_dev;
		    lookahead_point_distance = PurePursuitParam.lookahead_point_distance;	
			lookahead_factor_val = PurePursuitParam.lookahead_factor_val;
			lookahead_jump_threshold = PurePursuitParam.lookahead_jump_threshold;	
		}
	};
	struct MaxlReconfigure
	{
		struct PurePursuitParam purepursuitparam;
	   	double sensorOffsetX;
	    double sensorOffsetY;
	    double maxSpeed;
	    double maxAccel;
	    double highAccuracyMultiplier;
	    double yawRateGain;
	    double stopYawRateGain;
	    double maxYawRate; 
	   	double dirWeight;
	   	double dirThre;
	    double xInflate;
	    double yInflate;
	    double adjacentRange;
	    double minPathRange;
	    double visPointCloud;
	    double in_place_rotation_penalty;
	    double goal_direction_preference;
	    int scoring_algo_index;
	    double pi_osc_senstivity;
	    int pi_osc_threshold;
	    double av_osc_sample_window;
	    double av_osc_freq_threshold;
	    bool osc_det_by_path_index;
	    bool osc_det_by_angular_velocity;
	    int scoring_algo_four_senstivity_factor;
	    //trucate scoring
	    int truncated_fan_angle;
	};

	struct MaxlScoringParams
	{
		double dirDiff;
		int rotDir;
		double joyDir;
		double penaltyScore;
		double costScore;
		double dirWeight;
		double in_place_rotation_penalty;
		double goal_direction_preference;
		bool is_oscillating;
		int scoring_index;
		int scoring_algo_four_senstivity_factor;
		
		MaxlScoringParams()
		{
			dirDiff= 0.02;
			rotDir= 0;
			joyDir= 0;
			penaltyScore= 0;
			costScore= 0;
			dirWeight= 0;
			in_place_rotation_penalty= 0.05;
			goal_direction_preference= 0.2;
			is_oscillating = false;
			scoring_index = 1;
			scoring_algo_four_senstivity_factor =0;			
		}
		
		void set(	double dirDiff_in,
							int rotDir_in,
							double joyDir_in,
							double penaltyScore_in,
							double costScore_in,
							double dirWeight_in,
							double in_place_rotation_penalty_in,
							double goal_direction_preference_in,
							bool is_oscillating_in,
							int scoring_index_in,
							int scoring_algo_four_senstivity_factor_in)
		{
			dirDiff = dirDiff_in;
			rotDir = rotDir_in;
			joyDir = joyDir_in;
			penaltyScore = penaltyScore_in;
			costScore = costScore_in;
			dirWeight = dirWeight_in;
			in_place_rotation_penalty = in_place_rotation_penalty_in;
			goal_direction_preference = goal_direction_preference_in;
			is_oscillating = is_oscillating_in;
			scoring_index = scoring_index_in;
			scoring_algo_four_senstivity_factor = scoring_algo_four_senstivity_factor_in;
		}
	};

	struct maxlRobotConfigParams
	{
		std::string pathFolder = "";
		std::string pathFile = "/paths";

		maxlRobotConfigParams()
		{}
		
		maxlRobotConfigParams(std::string folder_in,
		                      std::string file_in)
		{
			pathFolder = folder_in;
		    pathFile = file_in;
		}
	};

	struct maxlSpeedAccel
	{
        double maxSpeed = 0.4;
		double maxAccel = 0.5;

		maxlSpeedAccel()
		{}
		
		maxlSpeedAccel(double maxSpeed_in,
		         double maxAccel_in)
		{
			maxSpeed = maxSpeed_in;
			maxAccel = maxAccel_in;
		}
	};

	struct maxlTuningParams
	{
		double yaw_gain = 2.5;
		double stop_yaw_gain = 0.6;
		double max_yaw_rate = 0.5;

		maxlTuningParams()
		{}
		
		maxlTuningParams(double yaw_gain_in,
		                 double stop_yaw_gain_in,
		                 double max_yaw_rate_in)
		{
			yaw_gain = yaw_gain_in;
		    stop_yaw_gain = stop_yaw_gain_in;
		    max_yaw_rate = max_yaw_rate_in;
		}
	};

	struct maxlInflationParams
	{
        double x_inflate = 0.16;
		double y_inflate = 0.80;

		maxlInflationParams()
		{}

		maxlInflationParams(double x_inflate_in,
		                    double y_inflate_in)
		{
			x_inflate = x_inflate_in;
		    y_inflate = y_inflate_in;
		}
	};

	struct maxlFrames
	{
		std::string map_frame;
		std::string robot_frame;
		std::string velodyne_frame;

		maxlFrames()
		{}

		maxlFrames(std::string map_frame_in,
    		       std::string robot_frame_in,
		           std::string velodyne_frame_in)
		{
			map_frame = map_frame_in;
		    robot_frame = robot_frame_in;
		    velodyne_frame = velodyne_frame_in;
		}
	};

	struct maxlRobotFootprintParams
	{
		double vehicleLength = 0.22;
		double vehicleWidth = 0.22;
		double sensorOffsetX = 0.0;
		double sensorOffsetY = 0.0;

		maxlRobotFootprintParams()
		{}

		maxlRobotFootprintParams(double vehicleLength_in,
                                 double vehicleWidth_in,
                                 double sensorOffsetX_in,
                                 double sensorOffsetY_in)
		{
            vehicleLength = vehicleLength_in;
		    vehicleWidth = vehicleWidth_in;
		    sensorOffsetX = sensorOffsetX_in;
		    sensorOffsetY = sensorOffsetY_in;
		}
	};

	struct maxlObstacleRanges
	{
		double adjacentRange = 3.5;
		double minPathRange = 1.0;
		double pathScale = 1.0;
		double minPathScale = 0.75;
		double pathScaleStep = 0.25;

		maxlObstacleRanges()
		{}

		maxlObstacleRanges(double adjacentRange_in,
                           double minPathRange_in,
                           double pathScale_in,
                           double minPathScale_in,
                           double pathScaleStep_in)
		{
			adjacentRange = adjacentRange_in;
			minPathRange = minPathRange_in;
			pathScale = pathScale_in;
			minPathScale = minPathScale_in;
			pathScaleStep = pathScaleStep_in;
		}
	};

    struct maxlMiscellaneousParams
	{
		double dir_threshold = 120;
		double dir_weight = 0.02;
		double high_accuracy_multiplier = 0.5;
		bool vis_pointcloud = true;
		bool use_odom_velocity = true;
		bool reverse_enabled = false;
		int truncated_fan_angle = 10;
		int pathNum;
		int groupNum;

		maxlMiscellaneousParams()
		{}

		maxlMiscellaneousParams(double dir_threshold_in,
								double dir_weight_in,
		                        double high_accuracy_multiplier_in,
				                bool vis_pointcloud_in,
				                bool use_odom_velocity_in,
				                bool reverse_enabled_in,
				                int truncated_fan_angle_in,
								int pathNum_in,
								int groupNum_in)
		{
			dir_threshold = dir_threshold_in;
			dir_weight = dir_weight_in;
			high_accuracy_multiplier = high_accuracy_multiplier_in;
			vis_pointcloud = vis_pointcloud_in;
			use_odom_velocity = use_odom_velocity_in;
			reverse_enabled = reverse_enabled_in;
			truncated_fan_angle = truncated_fan_angle_in;
		    pathNum = pathNum_in;
			groupNum = groupNum_in;
	   }
	};

	struct maxlOscPathIndex
	{
		double pi_osc_senstivity = 5.0;
        int pi_osc_threshold = 10;
		bool osc_det_by_path_index = false;

        maxlOscPathIndex()
		{}

		maxlOscPathIndex(double pi_osc_senstivity_in,
                         int pi_osc_threshold_in,
				         bool osc_det_by_path_index_in)
		{
			pi_osc_senstivity = pi_osc_senstivity_in;
            pi_osc_threshold = pi_osc_threshold_in;
			osc_det_by_path_index = osc_det_by_path_index_in;
		}
	};

	struct maxlOscAngVel
	{
        double av_osc_freq_threshold = 3.5;
		double av_osc_sample_window = 1.0;
        bool osc_det_by_angular_velocity = true;
        double av_max_angular_velocity = 1.0;

		maxlOscAngVel()
		{}

		maxlOscAngVel(double av_osc_freq_threshold_in,
				      double av_osc_sample_window_in,
                      bool osc_det_by_ang_vel_in,
                      double av_max_angular_velocity_in)
		{
            av_osc_freq_threshold = av_osc_freq_threshold_in;
			av_osc_sample_window = av_osc_sample_window_in;
            osc_det_by_angular_velocity = osc_det_by_ang_vel_in;
            av_max_angular_velocity = av_max_angular_velocity_in;
		}
	};

	struct maxlScoringParams
	{
		int scoring_algo_index = 1;
        int scoring_algo_four_senstivity_factor = 0;
		double in_place_rotation_penalty = 0.05;
		double goal_direction_preference = 0.2;

		maxlScoringParams()
		{}

		maxlScoringParams(int scoring_algo_index_in,
		                  int scoring_algo_four_senstivity_factor_in,
                          double in_place_rotation_penalty_in,
						  double goal_direction_preference_in)
		{
            scoring_algo_index = scoring_algo_index_in;
            scoring_algo_four_senstivity_factor = scoring_algo_four_senstivity_factor_in;
			in_place_rotation_penalty = in_place_rotation_penalty_in;
		    goal_direction_preference = goal_direction_preference_in;
		}
	};

	struct maxlControllerParams
	{
		double lookAheadDis = 0.5;
		double uniform_global_plan_threshold = 0.04;

		maxlControllerParams()
		{}

		maxlControllerParams(double lookAheadDis_in,
							 double uniform_global_plan_threshold_in)
		{
			lookAheadDis = lookAheadDis_in;
			uniform_global_plan_threshold = uniform_global_plan_threshold_in;
		}
	};
}

#endif // MAXL_PLANNER_STRUCTS_
