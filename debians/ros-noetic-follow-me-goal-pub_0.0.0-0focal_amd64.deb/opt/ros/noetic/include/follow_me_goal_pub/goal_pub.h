/**
* @file goal_sim.h
* @author Divyanshu Sahu
* @brief This node takes the tracker position given by the tracker_sim node and publishes the goal position for the robot to follow
*/
#pragma once
//required header files

#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <geometry_msgs/Pose.h>
#include <stdio.h>
#include <unistd.h>
#include <termios.h>
#include <tf/transform_broadcaster.h>
#include <tf/transform_listener.h>
#include <map>
#include <deque>
#include <visualization_msgs/Marker.h>
#include <tf/transform_datatypes.h>
#include <vector>
#include <string>
#include <mw_msgs/mission_status.h>
#include <stdlib.h>
#include <cmath>
#include <mw_core/utility_functions.h>
#include <boost/shared_ptr.hpp>

namespace mw_tracker{

	class mw_goal
	{
		public:
			mw_goal();

			void trackerGoalCallback(const geometry_msgs::PoseStamped::Ptr& msg);

			void publishGoalMarker(double x_pos, double y_pos, geometry_msgs::Quaternion goal_orientation);

			void executiveStatusCallback(const mw_msgs::mission_status::Ptr& msg);

			float distanceToRobot(float goal_x, float goal_y, float robot_x, float robot_y);

			void publishGoal(float goal_x, float goal_y, float goal_yaw);

			geometry_msgs::Quaternion createQuaternionFromRPY(double roll, double pitch, double yaw);

			void GoalExecute();

		private:

			ros::NodeHandle n_;
			ros::NodeHandle private_n_;
			std::string goal_pub_topic_, tracker_position_topic_;
			std::string map_frame_, goal_frame_ ;
			std::string mission_executive_status_topic_;
			ros::Subscriber tracker_sub_; //subscribing to the tracker_sim goal topic
			ros::Subscriber mission_executive_status_sub_; //The topic name for information about the robot position
			ros::Publisher rviz_goal_pub_; //The topic name to publish goals to rviz
			ros::Publisher marker_pub_; 	//publishing marker for better visulaisation
			float tracker_current_pose_x_, tracker_current_pose_y_;
			float rviz_goal_pose_x_, rviz_goal_pose_y_, distance_from_tracker_;
			float robot_pose_x_, robot_pose_y_ ; //robot position variables
			float goal_pose_yaw_;
			float tracker_goal_tolerance_; //The tolerance between the tacker and the goal when the tracker is on the boundary of the assigned distance_from_tracker
			geometry_msgs::PoseStamped rviz_goal_pose_, robot_pose_;
			std::deque<geometry_msgs::PoseStamped> tracker_goal_queue_; //queue to collect tracker goals
	  		tf::TransformBroadcaster br_;
  			tf::Transform transform_;
			  TFPtr tf_listener_ptr_;
			  tf2_ros::TransformListener *tf_listener_;
	};
}
