// Auto-generated. Do not edit!

// (in-package mw_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Task = require('./Task.js');

//-----------------------------------------------------------

class Duty {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.id = null;
      this.total_tasks = null;
      this.tasks = null;
      this.loop_enabled = null;
    }
    else {
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = 0;
      }
      if (initObj.hasOwnProperty('total_tasks')) {
        this.total_tasks = initObj.total_tasks
      }
      else {
        this.total_tasks = 0;
      }
      if (initObj.hasOwnProperty('tasks')) {
        this.tasks = initObj.tasks
      }
      else {
        this.tasks = [];
      }
      if (initObj.hasOwnProperty('loop_enabled')) {
        this.loop_enabled = initObj.loop_enabled
      }
      else {
        this.loop_enabled = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Duty
    // Serialize message field [id]
    bufferOffset = _serializer.uint32(obj.id, buffer, bufferOffset);
    // Serialize message field [total_tasks]
    bufferOffset = _serializer.uint64(obj.total_tasks, buffer, bufferOffset);
    // Serialize message field [tasks]
    // Serialize the length for message field [tasks]
    bufferOffset = _serializer.uint32(obj.tasks.length, buffer, bufferOffset);
    obj.tasks.forEach((val) => {
      bufferOffset = Task.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [loop_enabled]
    bufferOffset = _serializer.bool(obj.loop_enabled, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Duty
    let len;
    let data = new Duty(null);
    // Deserialize message field [id]
    data.id = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [total_tasks]
    data.total_tasks = _deserializer.uint64(buffer, bufferOffset);
    // Deserialize message field [tasks]
    // Deserialize array length for message field [tasks]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.tasks = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.tasks[i] = Task.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [loop_enabled]
    data.loop_enabled = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.tasks.forEach((val) => {
      length += Task.getMessageSize(val);
    });
    return length + 17;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mw_msgs/Duty';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5e7fb4e76103808f6a0b7d1a86e3932b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Unique ID for each duty
    uint32 id
    
    # Total number of tasks
    uint64 total_tasks
    
    # List of tasks
    mw_msgs/Task[] tasks
    
    # Is loop enabled
    bool loop_enabled
    ================================================================================
    MSG: mw_msgs/Task
    # Unique ID for each task
    uint32 id
    
    # task_goal field when type is GTG
    mw_msgs/Route route
    geometry_msgs/Pose task_goal
    
    # Duration (in seconds) to run this task (when type is not ROUTE)
    float32 duration
    
    # End behaviour, ie, time to wait after this task ends and before starting the next task
    float32 end_behaviour
    
    # Enumeration for different types
    uint8 GTG=0
    uint8 WAIT=1
    
    # Type of task
    uint8 type
    
    
    # Enumeration for different task states
    uint8 NOT_STARTED=0
    uint8 WIP=1
    uint8 COMPLETED=2
    
    # Task status
    uint8 status
    
    
    ================================================================================
    MSG: mw_msgs/Route
    # Unique ID for each different route
    uint32 id
    
    # Header
    std_msgs/Header header
    
    # Array of waypoints
    geometry_msgs/PoseStamped[] waypoints
    
    # Route status
    uint8 status
    
    # Enumeration for different route states
    uint8 NOT_STARTED=0
    uint8 WIP=1
    uint8 COMPLETED=2
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/PoseStamped
    # A Pose with reference coordinate frame and timestamp
    Header header
    Pose pose
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Duty(null);
    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = 0
    }

    if (msg.total_tasks !== undefined) {
      resolved.total_tasks = msg.total_tasks;
    }
    else {
      resolved.total_tasks = 0
    }

    if (msg.tasks !== undefined) {
      resolved.tasks = new Array(msg.tasks.length);
      for (let i = 0; i < resolved.tasks.length; ++i) {
        resolved.tasks[i] = Task.Resolve(msg.tasks[i]);
      }
    }
    else {
      resolved.tasks = []
    }

    if (msg.loop_enabled !== undefined) {
      resolved.loop_enabled = msg.loop_enabled;
    }
    else {
      resolved.loop_enabled = false
    }

    return resolved;
    }
};

module.exports = Duty;
