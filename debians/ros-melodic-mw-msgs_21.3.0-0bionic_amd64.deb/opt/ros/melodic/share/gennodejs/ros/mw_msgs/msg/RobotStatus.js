// Auto-generated. Do not edit!

// (in-package mw_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let mission_status = require('./mission_status.js');
let sensor_msgs = _finder('sensor_msgs');

//-----------------------------------------------------------

class RobotStatus {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.robot_id = null;
      this.robot_ip = null;
      this.robot_type = null;
      this.current_duty_id = null;
      this.current_task_id = null;
      this.task_type = null;
      this.robot_mission_status = null;
      this.robot_battery_state = null;
      this.error_code = null;
    }
    else {
      if (initObj.hasOwnProperty('robot_id')) {
        this.robot_id = initObj.robot_id
      }
      else {
        this.robot_id = '';
      }
      if (initObj.hasOwnProperty('robot_ip')) {
        this.robot_ip = initObj.robot_ip
      }
      else {
        this.robot_ip = '';
      }
      if (initObj.hasOwnProperty('robot_type')) {
        this.robot_type = initObj.robot_type
      }
      else {
        this.robot_type = '';
      }
      if (initObj.hasOwnProperty('current_duty_id')) {
        this.current_duty_id = initObj.current_duty_id
      }
      else {
        this.current_duty_id = 0;
      }
      if (initObj.hasOwnProperty('current_task_id')) {
        this.current_task_id = initObj.current_task_id
      }
      else {
        this.current_task_id = 0;
      }
      if (initObj.hasOwnProperty('task_type')) {
        this.task_type = initObj.task_type
      }
      else {
        this.task_type = 0;
      }
      if (initObj.hasOwnProperty('robot_mission_status')) {
        this.robot_mission_status = initObj.robot_mission_status
      }
      else {
        this.robot_mission_status = new mission_status();
      }
      if (initObj.hasOwnProperty('robot_battery_state')) {
        this.robot_battery_state = initObj.robot_battery_state
      }
      else {
        this.robot_battery_state = new sensor_msgs.msg.BatteryState();
      }
      if (initObj.hasOwnProperty('error_code')) {
        this.error_code = initObj.error_code
      }
      else {
        this.error_code = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RobotStatus
    // Serialize message field [robot_id]
    bufferOffset = _serializer.string(obj.robot_id, buffer, bufferOffset);
    // Serialize message field [robot_ip]
    bufferOffset = _serializer.string(obj.robot_ip, buffer, bufferOffset);
    // Serialize message field [robot_type]
    bufferOffset = _serializer.string(obj.robot_type, buffer, bufferOffset);
    // Serialize message field [current_duty_id]
    bufferOffset = _serializer.uint32(obj.current_duty_id, buffer, bufferOffset);
    // Serialize message field [current_task_id]
    bufferOffset = _serializer.uint32(obj.current_task_id, buffer, bufferOffset);
    // Serialize message field [task_type]
    bufferOffset = _serializer.uint8(obj.task_type, buffer, bufferOffset);
    // Serialize message field [robot_mission_status]
    bufferOffset = mission_status.serialize(obj.robot_mission_status, buffer, bufferOffset);
    // Serialize message field [robot_battery_state]
    bufferOffset = sensor_msgs.msg.BatteryState.serialize(obj.robot_battery_state, buffer, bufferOffset);
    // Serialize message field [error_code]
    bufferOffset = _serializer.int32(obj.error_code, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RobotStatus
    let len;
    let data = new RobotStatus(null);
    // Deserialize message field [robot_id]
    data.robot_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [robot_ip]
    data.robot_ip = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [robot_type]
    data.robot_type = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [current_duty_id]
    data.current_duty_id = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [current_task_id]
    data.current_task_id = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [task_type]
    data.task_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [robot_mission_status]
    data.robot_mission_status = mission_status.deserialize(buffer, bufferOffset);
    // Deserialize message field [robot_battery_state]
    data.robot_battery_state = sensor_msgs.msg.BatteryState.deserialize(buffer, bufferOffset);
    // Deserialize message field [error_code]
    data.error_code = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.robot_id.length;
    length += object.robot_ip.length;
    length += object.robot_type.length;
    length += mission_status.getMessageSize(object.robot_mission_status);
    length += sensor_msgs.msg.BatteryState.getMessageSize(object.robot_battery_state);
    return length + 25;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mw_msgs/RobotStatus';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'dbf9f4fa0cb9be86b1bc9e86d3fb639b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # robot status for UI
    
    # robot id
    string robot_id
    
    # robot ip
    string robot_ip
    
    # robot type
    string robot_type
    
    # 0 means no duty set / any positive integer represents a duty
    uint32 current_duty_id
    
    # if no duty set this is gibberish otherwise it represents the task id currently running
    uint32 current_task_id
    
    # if no duty set this is gibberish otherwise it represents type of current task 0 == route 1 == attachement task
    uint8 task_type
    
    # robot mission status
    mw_msgs/mission_status robot_mission_status
    
    # robot battery state
    sensor_msgs/BatteryState robot_battery_state
    
    # 0 == all is well any positive int means there is an issue for now just display the number
    int32 error_code
    
    
    ================================================================================
    MSG: mw_msgs/mission_status
    # status indicating the navigation mode of executive (AUTONOMY/MANUAL/SAFETELEOP)
    string nav_mode
    
    # status indicating machine state (PLANNING/CONTROLLING/RECOVERING/WAITING/NA) (NA state is when mission nav_mode is working in Manual or Safe telop mode)
    string autonomy_state
    
    # status indicating name of the controller type being used
    string controller_type
    
    # status indicating name of the global planner type being used
    string global_planner_type
    
    # status indicating current position and orientation of the robot
    geometry_msgs/PoseStamped current_pose
    
    # status indicating the current goal being pursued by the robot 
    geometry_msgs/PoseStamped current_goal
    ================================================================================
    MSG: geometry_msgs/PoseStamped
    # A Pose with reference coordinate frame and timestamp
    Header header
    Pose pose
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: sensor_msgs/BatteryState
    
    # Constants are chosen to match the enums in the linux kernel
    # defined in include/linux/power_supply.h as of version 3.7
    # The one difference is for style reasons the constants are
    # all uppercase not mixed case.
    
    # Power supply status constants
    uint8 POWER_SUPPLY_STATUS_UNKNOWN = 0
    uint8 POWER_SUPPLY_STATUS_CHARGING = 1
    uint8 POWER_SUPPLY_STATUS_DISCHARGING = 2
    uint8 POWER_SUPPLY_STATUS_NOT_CHARGING = 3
    uint8 POWER_SUPPLY_STATUS_FULL = 4
    
    # Power supply health constants
    uint8 POWER_SUPPLY_HEALTH_UNKNOWN = 0
    uint8 POWER_SUPPLY_HEALTH_GOOD = 1
    uint8 POWER_SUPPLY_HEALTH_OVERHEAT = 2
    uint8 POWER_SUPPLY_HEALTH_DEAD = 3
    uint8 POWER_SUPPLY_HEALTH_OVERVOLTAGE = 4
    uint8 POWER_SUPPLY_HEALTH_UNSPEC_FAILURE = 5
    uint8 POWER_SUPPLY_HEALTH_COLD = 6
    uint8 POWER_SUPPLY_HEALTH_WATCHDOG_TIMER_EXPIRE = 7
    uint8 POWER_SUPPLY_HEALTH_SAFETY_TIMER_EXPIRE = 8
    
    # Power supply technology (chemistry) constants
    uint8 POWER_SUPPLY_TECHNOLOGY_UNKNOWN = 0
    uint8 POWER_SUPPLY_TECHNOLOGY_NIMH = 1
    uint8 POWER_SUPPLY_TECHNOLOGY_LION = 2
    uint8 POWER_SUPPLY_TECHNOLOGY_LIPO = 3
    uint8 POWER_SUPPLY_TECHNOLOGY_LIFE = 4
    uint8 POWER_SUPPLY_TECHNOLOGY_NICD = 5
    uint8 POWER_SUPPLY_TECHNOLOGY_LIMN = 6
    
    Header  header
    float32 voltage          # Voltage in Volts (Mandatory)
    float32 current          # Negative when discharging (A)  (If unmeasured NaN)
    float32 charge           # Current charge in Ah  (If unmeasured NaN)
    float32 capacity         # Capacity in Ah (last full capacity)  (If unmeasured NaN)
    float32 design_capacity  # Capacity in Ah (design capacity)  (If unmeasured NaN)
    float32 percentage       # Charge percentage on 0 to 1 range  (If unmeasured NaN)
    uint8   power_supply_status     # The charging status as reported. Values defined above
    uint8   power_supply_health     # The battery health metric. Values defined above
    uint8   power_supply_technology # The battery chemistry. Values defined above
    bool    present          # True if the battery is present
    
    float32[] cell_voltage   # An array of individual cell voltages for each cell in the pack
                             # If individual voltages unknown but number of cells known set each to NaN
    string location          # The location into which the battery is inserted. (slot number or plug)
    string serial_number     # The best approximation of the battery serial number
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RobotStatus(null);
    if (msg.robot_id !== undefined) {
      resolved.robot_id = msg.robot_id;
    }
    else {
      resolved.robot_id = ''
    }

    if (msg.robot_ip !== undefined) {
      resolved.robot_ip = msg.robot_ip;
    }
    else {
      resolved.robot_ip = ''
    }

    if (msg.robot_type !== undefined) {
      resolved.robot_type = msg.robot_type;
    }
    else {
      resolved.robot_type = ''
    }

    if (msg.current_duty_id !== undefined) {
      resolved.current_duty_id = msg.current_duty_id;
    }
    else {
      resolved.current_duty_id = 0
    }

    if (msg.current_task_id !== undefined) {
      resolved.current_task_id = msg.current_task_id;
    }
    else {
      resolved.current_task_id = 0
    }

    if (msg.task_type !== undefined) {
      resolved.task_type = msg.task_type;
    }
    else {
      resolved.task_type = 0
    }

    if (msg.robot_mission_status !== undefined) {
      resolved.robot_mission_status = mission_status.Resolve(msg.robot_mission_status)
    }
    else {
      resolved.robot_mission_status = new mission_status()
    }

    if (msg.robot_battery_state !== undefined) {
      resolved.robot_battery_state = sensor_msgs.msg.BatteryState.Resolve(msg.robot_battery_state)
    }
    else {
      resolved.robot_battery_state = new sensor_msgs.msg.BatteryState()
    }

    if (msg.error_code !== undefined) {
      resolved.error_code = msg.error_code;
    }
    else {
      resolved.error_code = 0
    }

    return resolved;
    }
};

module.exports = RobotStatus;
