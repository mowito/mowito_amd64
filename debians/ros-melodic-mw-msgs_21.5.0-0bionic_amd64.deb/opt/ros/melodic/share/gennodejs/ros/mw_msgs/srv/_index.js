
"use strict";

let SetString = require('./SetString.js')
let SetDuty = require('./SetDuty.js')
let SetMode = require('./SetMode.js')
let SetNodeState = require('./SetNodeState.js')
let GetRouteStatus = require('./GetRouteStatus.js')
let SetTask = require('./SetTask.js')
let ComputeCircumscribedCost = require('./ComputeCircumscribedCost.js')
let GetTask = require('./GetTask.js')
let LoadTaskFromFile = require('./LoadTaskFromFile.js')
let GetDuty = require('./GetDuty.js')
let GetRoute = require('./GetRoute.js')
let GetSbplPlan = require('./GetSbplPlan.js')
let LoadRouteFromFile = require('./LoadRouteFromFile.js')
let GetPlan = require('./GetPlan.js')
let FleetStatus = require('./FleetStatus.js')
let GetTaskStatus = require('./GetTaskStatus.js')
let SetRobotFootprint = require('./SetRobotFootprint.js')
let GetPose = require('./GetPose.js')
let SetCost = require('./SetCost.js')
let SetPlan = require('./SetPlan.js')
let ChangeMprims = require('./ChangeMprims.js')
let GetCircumscribedRadius = require('./GetCircumscribedRadius.js')
let RobotInfo = require('./RobotInfo.js')
let GetString = require('./GetString.js')
let SetManual = require('./SetManual.js')
let LoadDutyFromFile = require('./LoadDutyFromFile.js')
let GetDouble = require('./GetDouble.js')
let SetRoute = require('./SetRoute.js')

module.exports = {
  SetString: SetString,
  SetDuty: SetDuty,
  SetMode: SetMode,
  SetNodeState: SetNodeState,
  GetRouteStatus: GetRouteStatus,
  SetTask: SetTask,
  ComputeCircumscribedCost: ComputeCircumscribedCost,
  GetTask: GetTask,
  LoadTaskFromFile: LoadTaskFromFile,
  GetDuty: GetDuty,
  GetRoute: GetRoute,
  GetSbplPlan: GetSbplPlan,
  LoadRouteFromFile: LoadRouteFromFile,
  GetPlan: GetPlan,
  FleetStatus: FleetStatus,
  GetTaskStatus: GetTaskStatus,
  SetRobotFootprint: SetRobotFootprint,
  GetPose: GetPose,
  SetCost: SetCost,
  SetPlan: SetPlan,
  ChangeMprims: ChangeMprims,
  GetCircumscribedRadius: GetCircumscribedRadius,
  RobotInfo: RobotInfo,
  GetString: GetString,
  SetManual: SetManual,
  LoadDutyFromFile: LoadDutyFromFile,
  GetDouble: GetDouble,
  SetRoute: SetRoute,
};
