// Auto-generated. Do not edit!

// (in-package mw_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class SetManualRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.manual_mode = null;
    }
    else {
      if (initObj.hasOwnProperty('manual_mode')) {
        this.manual_mode = initObj.manual_mode
      }
      else {
        this.manual_mode = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetManualRequest
    // Serialize message field [manual_mode]
    bufferOffset = _serializer.bool(obj.manual_mode, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetManualRequest
    let len;
    let data = new SetManualRequest(null);
    // Deserialize message field [manual_mode]
    data.manual_mode = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'mw_msgs/SetManualRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '40db758ee4eca31614e1f6f551c1414f';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool manual_mode
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetManualRequest(null);
    if (msg.manual_mode !== undefined) {
      resolved.manual_mode = msg.manual_mode;
    }
    else {
      resolved.manual_mode = false
    }

    return resolved;
    }
};

class SetManualResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetManualResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetManualResponse
    let len;
    let data = new SetManualResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'mw_msgs/SetManualResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '358e233cde0c8a8bcfea4ce193f8fc15';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool success
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetManualResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    return resolved;
    }
};

module.exports = {
  Request: SetManualRequest,
  Response: SetManualResponse,
  md5sum() { return 'a503a0126e6f2557a6606a8c02d36c1f'; },
  datatype() { return 'mw_msgs/SetManual'; }
};
